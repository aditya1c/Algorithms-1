import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    // private final WeightedQuickUnionUF normalQU;
    private final WeightedQuickUnionUF backwashQU;
    private final boolean[] isOpen;
    private final int topIndex;
    private final int btmIndex;
    private final int n;
    private int openCount;

    /**
     * Create n-by-n grid, with all sites blocked
     *
     * @param n length and width of the grid
     */
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n must be greater than 0.");
        }
        this.n = n;
        topIndex = 0;
        btmIndex = n * n + 1;
        backwashQU = new WeightedQuickUnionUF(n * n + 2);
        // normalQU = new WeightedQuickUnionUF(n * n + 1);  // wihout bottom index
        isOpen = new boolean[n * n + 2];
        isOpen[topIndex] = true;
        isOpen[btmIndex] = true;
    }

    /**
     * Convert a 2D coordinate to 1D.
     *
     * @param row base-1 index of row
     * @param col base-1 index of column
     */
    private int indexOf(int row, int col) {
        // check bounds
        if (row < 1 || row > n) {
            throw new IndexOutOfBoundsException("Row is out of bounds.");
        }
        if (col < 1 || col > n) {
            throw new IndexOutOfBoundsException("Column is out of bounds.");
        }
        return (row - 1) * n + col;
    }

    /**
     * Open site (row, col) if it is not open already
     *
     * @param row base-1 index of row
     * @param col base-1 index of column
     */
    public void open(int row, int col) {
        int currIndex = indexOf(row, col);
        isOpen[currIndex] = true;
        openCount++;

        if (row == 1) {
            backwashQU.union(currIndex, topIndex);  // Top
            // normalQU.union(currIndex, topIndex);
        }
        if (row == n) {
            backwashQU.union(currIndex, btmIndex);  // Bottom
        }
        tryUnion(row, col, row - 1, col);  // North
        tryUnion(row, col, row + 1, col);  // South
        tryUnion(row, col, row, col - 1);  // West
        tryUnion(row, col, row, col + 1);  // East
    }

    private void tryUnion(int rowA, int colA, int rowB, int colB) {
        // I assume that (rowA, colA) is correct.
        if (0 < rowB && rowB <= n && 0 < colB && colB <= n
                && isOpen(rowB, colB)) {
            backwashQU.union(indexOf(rowA, colA), indexOf(rowB, colB));
            // normalQU.union(indexOf(rowA, colA), indexOf(rowB, colB));
        }
    }

    /**
     * Returns the number of open sites
     */
    public int numberOfOpenSites(){
        return openCount;
    }

    /**
     * Is site (row, col) open?
     *
     * @param row base-1 index of row
     * @param col base-1 index of column
     */
    public boolean isOpen(int row, int col) {
        return isOpen[indexOf(row, col)];
    }

    /**
     * Is site (row, col) full?
     *
     * @param row base-1 index of row
     * @param col base-1 index of column
     */
    public boolean isFull(int row, int col) {
        // return normalQU.connected(topIndex, indexOf(row, col));
        return !isOpen[indexOf(row, col)];
    }

    /**
     * Does the system percolate?
     */
    public boolean percolates() {
        return backwashQU.connected(topIndex, btmIndex);
    }

    public static void main(String[] args) {
        StdOut.println("This class file is to define Percolation Data Structure. Run PercolationStats instead.");
    }
}